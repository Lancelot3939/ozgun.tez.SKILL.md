---
name: ozgun-tez-duzeltici
description: Akademik tez, makale ve rapor metinlerini 4 katmanlı bir dönüşümle yeniden yazarak AI-üretimi izlenimi veren monoton yapıyı kırar ve insan-yazımı doğallığına yaklaştırır. Tetikleme — 'tezimi düzenle', 'tezimi doğallaştır', 'AI gibi durmasın', 'özgünleştir', 'intihal benzerliği düşür', 'turnitin', 'GPTZero', 'AI detector', 'akademik metin düzenle', 'tez redaksiyonu', 'cümleleri ben yazmışım gibi', 'monoton durmasın', 'robotik durmuyor mu', 'daha insani yaz', 'katmanlı düzenle'. Kullanıcı akademik bir metin paylaşıp bunu yeniden yazma, doğallaştırma, AI izini silme veya üslup çeşitlendirme istediğinde mutlaka tetikle. Kullanıcı açıkça 'özgünleştir' demese bile akademik metinde monotonluk/yapaylık şikayeti varsa veya 'benim üslubuma uyarla' talebi geçerse bu skill devreye girmelidir.
---

# Özgün Tez Düzeltici

Bu skill, akademik metinleri (tez, makale, rapor, literatür taraması) 4 katmanlı bir dönüşüm süreciyle işler. Amaç: AI-üretimi metinlerin tipik imzalarını (cümle uzunluğu homojenliği, aşırı geçiş ifadeleri, kesin-emin dil, tek-tip kaynak atfı, kusursuz akış) ortadan kaldırıp metni insan-yazımı doğallığına yaklaştırmaktır. Anlam ve akademik içerik **değişmez**; değişen yalnızca yüzeydir.

## Ne zaman kullanılır

- Kullanıcı akademik bir metin (tez bölümü, makale paragrafı, rapor) paylaştığında
- "AI gibi duruyor", "monoton", "robotik", "hep aynı ritim" gibi şikayetler olduğunda
- Turnitin / GPTZero / AI-detector endişeleri dile getirildiğinde
- "Benim üslubuma uyarla" talebi geldiğinde
- Hazır metnin üslubu çeşitlendirilecekse

## Ne zaman kullanılmaz

- Kısa mesaj, e-posta, yaratıcı yazı için (bu skill akademik kayda özgüdür)
- Kullanıcı yalnızca imla/gramer kontrolü istiyorsa (o durumda `turkce-imla-anlatim` uygundur)
- Metin zaten kullanıcı tarafından yazılmış ve yalnızca ufak düzeltme isteniyorsa

## Temel kural

**Akademik içerik dokunulmazdır.** Argüman, bulgu, kaynak, sayı, terim, jargon — hepsi korunur. Dönüşüm yalnızca cümle yapısı, kelime seçimi, akış ve ritim katmanında olur.

---

## 4 Katmanlı Dönüşüm

Her katman **sırasıyla** uygulanır ve kullanıcıya ayrı ayrı gösterilir. Katmanlar birbirinin üzerine biner — yani Katman 2, Katman 1'in çıktısı üzerinde çalışır; Katman 3, Katman 2'nin çıktısı üzerinde; Katman 4, Katman 3'ün çıktısı üzerinde.

### Katman 1 — Ritim ve Yapı Kırma

**Cümle uzunluğu varyasyonu:** Hiçbir ardışık iki cümle aynı uzunlukta olmasın. Bir desen öner, kat sıkı uyma:

- Kısa cümle: 5–8 kelime
- Uzun cümle: 20–30 kelime
- Orta cümle: 10–12 kelime

Bu üçlüyü rastgele sırayla dolaştır. Tek düzeliği kır.

**Paragraf içi yapı:** Eğer orijinal paragrafta konu cümlesi hep başta ise, bazılarını ortaya, bazılarını sona taşı. Ama bir paragraftaki mantıksal akışı bozma.

**Çıktı formatı:** "Katman 1 — Ritim ve Yapı" başlığı altında dönüştürülmüş metni ver. Kısa bir not ekle: kaç cümle yeniden bölündü, kaç cümle birleştirildi.

### Katman 2 — Geçiş ve Bağlaç Seyreltme

**Say, sil, sadeleştir.** AI metinleri şu ifadelerle doludur: "bununla birlikte", "öte yandan", "ancak", "dolayısıyla", "bu bağlamda", "bu çerçevede", "nitekim", "keza", "sonuç olarak", "özetle".

Kural:
1. Metindeki bu tür geçiş ifadelerini say.
2. **Yarısını sil.** Geçiş ifadesi olmadan da cümle anlam kazanabiliyorsa — kazansın. İki cümlenin yan yana durması çoğu zaman bağlacı gereksiz kılar.
3. Kalanların bir kısmını günlük Türkçe karşılıklarıyla değiştir: "bununla birlikte" → "yine de"; "dolayısıyla" → "bu yüzden"; "öte yandan" → "ama"; "bu bağlamda" → (genelde silinir).
4. Aynı bağlacın ardışık paragraflarda tekrarına izin verme.

Tekrar eden kelimeleri eşanlamlılarıyla değiştir — ancak **teknik terim ve jargon dokunulmazdır.** "Kantitatif analiz" → "kantitatif analiz" kalır; "göstermiştir" → "ortaya koymuştur" olabilir.

**Çıktı:** "Katman 2 — Geçiş Seyreltme" başlığı altında metin + kısa istatistik: "X geçiş ifadesinden Y tanesi silindi, Z tanesi sadeleştirildi."

### Katman 3 — Hedging ve Kaynak Atfı Çeşitlendirme

**Kesinlik dilini yumuşat.** Akademik yazımda aşırı kesin ifadeler hem epistemik olarak tartışmalı hem de AI imzasıdır. Dönüşümler:

| Kesin ifade | Hedged karşılık |
|---|---|
| neden olmaktadır | yol açtığı düşünülmektedir / yol açabileceği öne sürülmektedir |
| göstermektedir | işaret edebileceği ileri sürülmektedir / düşündürmektedir |
| kanıtlamıştır | desteklemektedir / gösterir niteliktedir |
| dir / tir (kesin yargı) | olabilir / olduğu söylenebilir |
| her zaman | çoğunlukla / genellikle |
| hiçbir zaman | nadiren / sınırlı sayıda durumda |

**Kural:** Her paragrafta en az bir hedging ifadesi bulunsun. Ama hedging'i de monotonlaştırma — çeşit kullan.

**Kaynak atfı çeşitlendirme.** Eğer metinde kaynaklar hep "(Smith, 2019)" biçimindeyse, üçe böl:

1. **Cümle başı anlatımsal:** "Smith'e (2019) göre…"
2. **Parantez içi sonda:** "…bulgusu desteklenmiştir (Smith, 2019)."
3. **Tartışmacı format:** "Bu konuda Smith (2019) ve Yılmaz (2021) farklı görüştedir; Smith… savunurken, Yılmaz… vurgular."

Hedef dağılım kabaca 1/3, 1/3, 1/3. Metindeki tüm atıfları tek biçime hapsetme.

**Çıktı:** "Katman 3 — Hedging ve Atıf" başlığı altında metin.

### Katman 4 — Mikro Doğallaştırma

Burada metne insan-izi eklenir. 2–3 yere mikro kusur ve doğallık unsuru yerleştirilir:

- **Bir yere gereksiz ama doğal bir "aslında" ekle.** ("Bu bulgu aslında literatürdeki genel eğilimle örtüşmektedir.")
- **Bir cümlede özneyi geç getir.** ("Araştırmanın en çarpıcı sonucu, şaşırtıcı biçimde, kontrol grubundan geldi.")
- **Bir paragrafta konu cümlesini sona at** (eğer Katman 1'de yapılmadıysa).
- İsteğe bağlı: Bir yerde kısa, eliptik bir cümle ("Sonuç netti."). Bir yerde parantez içi bir yan düşünce.

**Sınır:** Mikro kusur **anlamı veya akademik tonu bozmaz.** Konuşma dili, argo, ünlem — yok. Sadece ritmik ve sözdizimsel bir "soluk alma".

**Çıktı:** "Katman 4 — Mikro Doğallaştırma" başlığı altında metin. Sonunda kısa bir liste: hangi mikro kusurların nereye eklendiği.

---

## Akış

Kullanıcı metni verdiğinde:

1. **Metni oku, türünü tespit et.** Tez girişi mi, literatür taraması mı, tartışma bölümü mü, yöntem mi? Her türün kendi konvansiyonu var — yöntem bölümü hedging'e daha az uygun, tartışma bölümü hedging'e çok uygun. Buna göre ayarla.

2. **Kullanıcının üslup tercihini sor** (eğer açıkça belirtilmemişse). Katman 3'te "benim yazım stilime uyarla" maddesi için 1–2 kısa örnek paragraf isteyebilirsin. Kullanıcı vermiyorsa, genel akademik Türkçe tonunu koru.

3. **4 katmanı sırayla uygula ve ayrı ayrı göster.** Tek seferde hepsini birleştirip sunma — kullanıcı her katmanı ayrı görmek ister, bu hem şeffaflık hem de seçmeli kullanım sağlar. (Kullanıcı ara katmanı beğenmezse tekrar isteyebilir.)

4. **Son olarak** birleşik nihai metni "Nihai Metin (4 katman uygulandı)" başlığı altında bütün olarak ver.

5. **Kısa bir dönüşüm notu** ekle: kaç cümle yeniden yapılandırıldı, kaç geçiş ifadesi silindi, kaç hedging eklendi, kaç mikro kusur yerleştirildi.

## Dikkat edilmesi gerekenler

- **Jargon ve teknik terimler dokunulmazdır.** "Regresyon analizi" kalır; "korelasyon katsayısı" kalır.
- **Sayılar, tarihler, yazar adları, yıllar dokunulmazdır.**
- **Alıntılar (tırnak içinde) dokunulmazdır.** Yalnızca çerçeveleme cümlesi değişebilir.
- **Anlamı koruma mutlak kuraldır.** Bir cümlenin iddiası değişirse, katman başarısızdır.
- Metin çok uzunsa (>2000 kelime), kullanıcıya paragraf paragraf mı yoksa bölüm bölüm mü işleyeceğini sor.
- Katman çıktıları arasında farkları **abartma**; mütevazı ve işlevsel göster.

## Uyarı

Bu skill akademik üslup çeşitlendirme ve doğallaştırma içindir. İntihal, sahte yazarlık veya akademik etik ihlali için kullanılmamalıdır. Metnin kaynakları, argümanları ve bulguları orijinal yazara aittir; skill yalnızca yüzey üslubu düzenler.
